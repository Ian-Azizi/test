package com.example.bandarabbasmall.service.Formes;

import com.example.bandarabbasmall.entites.Formes.Permit;
import com.example.bandarabbasmall.helper.Exception.DataNotFoundException;
import com.example.bandarabbasmall.repositores.Formes.PermitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PermitService {
    @Autowired
    private PermitRepository repository;

    public Permit getAllById(long id){
        Optional<Permit>data = repository.findAllById(id);
            if (data.isPresent()) return data.get();
            return null;
    }

    public Permit addData(Permit data){
        return repository.save(data);
    }
    public Permit upData(Permit data){
        Permit oldData = getAllById(data.getId());
        if (oldData==null){
            throw new DataNotFoundException("data with id"+data.getId()+"not found");
        }
        oldData.setDate(data.getDate());
        oldData.setImage(data.getImage());
        oldData.setForm_number(data.getForm_number());
        oldData.setLink(data.getLink());
        oldData.setTitle(data.getTitle());
        oldData.setCheck(data.isCheck());
        oldData.setDescription(data.getDescription());
        return repository.save(oldData);
    }
    public boolean deleteById(long id){
        Permit oldData = getAllById(id);
        if (oldData==null){
            throw new DataNotFoundException("data with id"+id+"not Found");
        }
        repository.deleteById(id);
        return true;
    }
}
