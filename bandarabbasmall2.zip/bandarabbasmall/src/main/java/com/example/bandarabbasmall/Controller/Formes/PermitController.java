package com.example.bandarabbasmall.Controller.Formes;


import com.example.bandarabbasmall.entites.Formes.Permit;
import com.example.bandarabbasmall.entites.Useres.User;
import com.example.bandarabbasmall.helper.ui.ResponseStatus;
import com.example.bandarabbasmall.helper.ui.ServiceResponse;
import com.example.bandarabbasmall.repositores.Formes.PermitRepository;
import com.example.bandarabbasmall.service.Formes.PermitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class PermitController {
    @Autowired
    private PermitService service;
    @Autowired
    private PermitRepository repository;

    @GetMapping("/Permit/get")
    List<Permit> all() {
        return (List<Permit>) repository.findAll();
    }

    @PostMapping("/Permit/Post")
    public ServiceResponse<Permit> addUser(@RequestBody Permit data) {
        try {
            Permit adding = service.addData(data);
            return new ServiceResponse<Permit>(ResponseStatus.SUCCESS, adding);
        } catch (Exception e) {
            return new ServiceResponse<Permit>(e);
        }
    }
    @PutMapping("/Permit/Put")
    public ServiceResponse<Permit> upDateUser(@RequestBody Permit data) {
        Permit result = service.upData(data);
        return new ServiceResponse<Permit>(ResponseStatus.SUCCESS,result);
    }
    @DeleteMapping("/delete/{id}")
    public ServiceResponse<Boolean> delete(@PathVariable long id) {
        try {
            boolean result = service.deleteById(id);
            return new ServiceResponse<Boolean>(ResponseStatus.SUCCESS, result);
        } catch (Exception e) {
            return new ServiceResponse<Boolean>(e);
        }
    }
}
