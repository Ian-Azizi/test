package com.example.bandarabbasmall.service.Formes;

import com.example.bandarabbasmall.entites.Formes.FormList;
import com.example.bandarabbasmall.helper.Exception.DataNotFoundException;
import com.example.bandarabbasmall.repositores.Formes.FormListRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class FormListService {
    @Autowired
    private FormListRepository repository;
    public FormList getAllById(long id){
        Optional<FormList>data = repository.findAllById(id);
        if (data.isPresent()) return data.get();
        return null;
    }

    public FormList addData(FormList data){
        return repository.save(data);
    }
    public FormList upData(FormList data){
        FormList oldData = getAllById(data.getId());
        if (oldData==null){
            throw new DataNotFoundException("data with id"+data.getId()+"not found");
        }
        oldData.setImage(data.getImage());
        oldData.setTitle(data.getTitle());
        oldData.setDescription(data.getDescription());
        oldData.setAddDate(data.getAddDate());
        oldData.setDescription(data.getDescription());
        return repository.save(oldData);
    }
    public boolean deleteById(long id){
        FormList oldData = getAllById(id);
        if (oldData==null){
            throw new DataNotFoundException("data with id"+id+"not Found");
        }
        repository.deleteById(id);
        return true;
    }
}
