package com.example.bandarabbasmall.entites.Formes;

import jakarta.persistence.*;

import java.util.Date;

@Entity
//this entites for save all the date in database (old forms and stuff)
public class FormList {
@GeneratedValue
    @Id
    private long id;
private String title;
private Date addDate;
private String image;
private String description;
    @ManyToOne
    //here connect permit to form list
    private Permit permit;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getAddDate() {
        return addDate;
    }

    public void setAddDate(Date addDate) {
        this.addDate = addDate;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Permit getPermit() {
        return permit;
    }

    public void setPermit(Permit permit) {
        this.permit = permit;
    }
}
