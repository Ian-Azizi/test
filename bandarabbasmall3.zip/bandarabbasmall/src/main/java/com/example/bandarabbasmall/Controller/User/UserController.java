package com.example.bandarabbasmall.Controller.User;


import com.example.bandarabbasmall.config.JwtTokenUtil;
import com.example.bandarabbasmall.entites.Useres.User;
import com.example.bandarabbasmall.helper.token.JwtRequest;
import com.example.bandarabbasmall.helper.token.JwtResponse;
import com.example.bandarabbasmall.helper.ui.ResponseStatus;
import com.example.bandarabbasmall.helper.ui.ServiceResponse;
import com.example.bandarabbasmall.repositores.Useres.UserRepository;
import com.example.bandarabbasmall.service.User.UserService;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@RestController
//final file for geting api
public class UserController {
    //first connect user service to user controller
    // don't need to connect userRepository because it's already connected to user Service

    @Autowired
    private UserService service;
    //but in this case we add userRepository because for get Api we would get lot of data and for make prosses shorter, we add user Repository
    @Autowired
    private UserRepository repository;
    //get Api unlike others is connected to repository itself and url is ("user/get") you can change it if you want

    @GetMapping("/user/get")
    List<User> all() {
        return repository.findAll();
    }
    //add new user here
    //TODO: create method for login(within token)
    @PostMapping("/user/post")
    public ServiceResponse<User> addUser(@RequestBody User Date) {
        try {
            User adding = service.add(Date);
            return new ServiceResponse<User>(ResponseStatus.SUCCESS, adding);
        } catch (Exception e) {
            return new ServiceResponse<User>(e);
        }
//        return new ServiceResponse<User>(ResponseStatus.SUCCESS, Date);

    }
    //upData all the data  we let to upData in userService
    @PutMapping("/user/put")
    public ServiceResponse<User> upDateUser(@RequestBody User data) {
        User updateData = service.upData(data);
        return new ServiceResponse<User>(ResponseStatus.SUCCESS, updateData);
    }
    //delete user be id
    @DeleteMapping("/{id}")
    public ServiceResponse<Boolean> delete(@PathVariable long id) {
        try {
            boolean result = service.delete(id);
            return new ServiceResponse<Boolean>(ResponseStatus.SUCCESS, result);
        } catch (Exception e) {
            return new ServiceResponse<Boolean>(e);
        }
    }
    @GetMapping("/user/test")
    public ServiceResponse<User>userSample(@RequestBody User data){
        try {
            List<User> result = service.userSample(data);
            return new ServiceResponse<User>(ResponseStatus.SUCCESS,result);
        }catch (Exception e){
            return new ServiceResponse<User>(e);
        }

    }
    @PostMapping("/user")
    public User login(@RequestParam String username,String pwd) {

        String token = getJWTToken(username);
        User user = new User();
        user.setUserName(username);
        user.setToken(token);
        return user;

    }

    private String getJWTToken(String username) {
        String secretKey = "mySecretKey";
        List<GrantedAuthority> grantedAuthorities = AuthorityUtils
                .commaSeparatedStringToAuthorityList("ROLE_USER");

        String token = Jwts
                .builder()
                .setId("softtekJWT")
                .setSubject(username)
                .claim("authorities",
                        grantedAuthorities.stream()
                                .map(GrantedAuthority::getAuthority)
                                .collect(Collectors.toList()))
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + 600000))
                .signWith(SignatureAlgorithm.HS512,
                        secretKey.getBytes()).compact();

        return "Bearer " + token;
    }

}
