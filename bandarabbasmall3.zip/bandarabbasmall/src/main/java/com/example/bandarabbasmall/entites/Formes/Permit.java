package com.example.bandarabbasmall.entites.Formes;

import com.example.bandarabbasmall.entites.Useres.User;
import jakarta.persistence.*;

import java.util.Date;

@Entity
public class Permit {
    @GeneratedValue
    @Id
    private long id;
    private String title;
    private String link;
    private String image;
    private String description;
    private boolean check;
    @ManyToOne
    private User user_kind;

    private Date date;
    private long Form_number;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isCheck() {
        return check;
    }

    public void setCheck(boolean check) {
        this.check = check;
    }

    public User getUser_kind() {
        return user_kind;
    }

    public void setUser_kind(User user_kind) {
        this.user_kind = user_kind;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public long getForm_number() {
        return Form_number;
    }

    public void setForm_number(long form_number) {
        Form_number = form_number;
    }
}
