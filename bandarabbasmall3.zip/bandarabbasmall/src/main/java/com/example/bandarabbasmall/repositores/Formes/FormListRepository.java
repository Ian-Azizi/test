package com.example.bandarabbasmall.repositores.Formes;

import com.example.bandarabbasmall.entites.Formes.FormList;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;


public interface FormListRepository extends CrudRepository<FormList,Long> {
    Optional<FormList> findAllById(long id);

}
