package com.example.bandarabbasmall.helper.Exception;

public class  DataNotFoundException extends RuntimeException{
    public DataNotFoundException(String message){
        super(message);
    }
}
