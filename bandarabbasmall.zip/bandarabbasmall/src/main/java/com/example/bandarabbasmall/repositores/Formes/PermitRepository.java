package com.example.bandarabbasmall.repositores.Formes;

import com.example.bandarabbasmall.entites.Formes.Permit;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
//connect Database to repository
public interface PermitRepository extends CrudRepository<Permit,Long> {
        Optional<Permit> findAllById(long id);

}
