package com.example.bandarabbasmall.repositores.Useres;

import com.example.bandarabbasmall.entites.Useres.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
//connect to database using CrudRepository method
public interface UserRepository  extends CrudRepository<User,Long> {
    //query for database undrestend ShopId
    @Query("FROM User where shopId=shopId")
    List<User> findAllByShopId(String ShopId);
    List<User>findAllByUserNameAndPassword(String username,String password);
    Optional<User> findAllById(long id);

  List<User> findAll();

}
