package com.example.bandarabbasmall.service.User;

import com.example.bandarabbasmall.entites.Useres.User;
import com.example.bandarabbasmall.helper.Exception.DataNotFoundException;
import com.example.bandarabbasmall.repositores.Useres.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;


@Service
//services file for API needes
public class UserService {
    //at first call userRepository for connecting to database and stuff like this
    @Autowired
    private UserRepository repository;
    //get All the user By there exclusively id
    // we get them all in List way because it's few diffrenent value in one look
    public User getAllById(long id) {
        Optional<User> data = repository.findAllById(id);
        if (data.isPresent()) return data.get();
        return null;
    }
    //TODO:get All by there own shopId

    public User getAll(String shopId) {
        return (User) repository.findAllByShopId(shopId);
    }
    //TODO:add token for sign up
    //here we save all the data user post in api
    public User add(User data){

        return repository.save(data);
    }
    //TODO: token and security stuff
    //here user can updata all the information user want
    public User upData(User data){
        User oldData = getAllById(data.getId());
        if (oldData==null){
            throw new DataNotFoundException("data with id"+data.getId()+"not found");
        }
        //data that
        oldData.setUserName(data.getUserName());
        oldData.setPassword(data.getPassword());
        oldData.setShopName(data.getShopName());
        oldData.setToken(data.getToken());
        oldData.setFistName(data.getFistName());
        oldData.setLastName(data.getLastName());
        return repository.save(oldData);
    }
    //delete data by there own id
    public boolean delete(long id){
        User oldData = getAllById(id);
        if (oldData==null){
            throw new DataNotFoundException("data with id"+id+"not found");
        }
        repository.deleteById(id);
        return true;
    }

}
