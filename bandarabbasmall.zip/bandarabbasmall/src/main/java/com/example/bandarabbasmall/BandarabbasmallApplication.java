package com.example.bandarabbasmall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BandarabbasmallApplication {

	public static void main(String[] args) {
		SpringApplication.run(BandarabbasmallApplication.class, args);
	}
}
